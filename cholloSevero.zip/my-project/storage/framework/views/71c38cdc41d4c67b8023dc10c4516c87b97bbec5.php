<?php $__env->startSection('eliminar'); ?>
    <div class="previsualizacion">
        <h3>Previsualización del chollo</h3>
        <h4><?php echo e($chollo->titulo); ?></h4>
        <p>Categoría: <?php echo e($chollo->categoria); ?></p>
        <p>Descripción: <?php echo e($chollo->descripcion); ?></p>
        <p>Precio original: <?php echo e($chollo->precio); ?>€</p>
        <p>Precio actual: <?php echo e($chollo->precio_descuento); ?>€</p>
        <p>Puntuación: <?php echo e($chollo->puntuacion); ?></p>
        <p>URL: <a href=<?php echo e($chollo->url); ?>><?php echo e($chollo->url); ?></a></p>
        <form action=<?php echo e(route("eliminar", $chollo->id)); ?> method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field("delete"); ?>
            <button class="btn btn-danger btn-block" onclick="return confirm('¿Estás seguro de que quieres eliminar este chollo?')" type="submit">
                Eliminar chollo
              </button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('static', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/chollos/eliminar.blade.php ENDPATH**/ ?>