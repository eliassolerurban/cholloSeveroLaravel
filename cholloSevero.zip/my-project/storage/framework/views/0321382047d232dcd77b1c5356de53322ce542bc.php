<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('logo.png')); ?>">
    <title>Chollo Severo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>">
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="titulo">
                <a href=<?php echo e(route('inicio')); ?>><img class="logo" src="<?php echo e(asset('logo.png')); ?>" alt="Logo de CholloSevero"></a>
                <a href=<?php echo e(route('inicio')); ?>><h1 class="display-5">Chollo Severo</h1></a>
            </div>
            </button>          
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                  <a class="nav-link" href=<?php echo e(route('inicio')); ?>>Inicio</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href=<?php echo e(route('nuevos')); ?>>Nuevos</a>
                </li>                <li class="nav-item">
                    <a class="nav-link" href=<?php echo e(route('destacados')); ?>>Destacados</a>
                </li>
              </ul>
            </div>
          </nav>
    </header>
    <main>
        <?php echo $__env->yieldContent('inicio'); ?>
        <?php echo $__env->yieldContent('nuevos'); ?>
        <?php echo $__env->yieldContent('destacados'); ?>
        <?php echo $__env->yieldContent('eliminar'); ?>
        <?php echo $__env->yieldContent('detalle'); ?>
        <?php echo $__env->yieldContent('editar'); ?>
        <?php echo $__env->yieldContent('crear'); ?>
        <div class="contenedorCrear">
            <a class="btn btn-primary" href=<?php echo e(route('formCrear')); ?>>Crear un chollo</a>
        </div>
    </main>
    <footer>
        <p>Elías Soler Urbán - ©CholloSevero <?php echo e(date("Y")); ?></p>
    </footer>
</body>
</html>
<?php /**PATH /app/resources/views/static.blade.php ENDPATH**/ ?>