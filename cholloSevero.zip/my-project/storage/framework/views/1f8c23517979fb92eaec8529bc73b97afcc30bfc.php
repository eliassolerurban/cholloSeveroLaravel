<?php $__env->startSection('inicio'); ?>
<h2>Nuevos chollos</h2>
<?php $__currentLoopData = $chollosNuevos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chollo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="container border">
    <div class="col m-3 p-1"><a href=<?php echo e(route("detalle", $chollo->id)); ?>><h4><?php echo e($chollo->titulo); ?></h4></a></div>
    <div class="col m-3 p-1"><p>Precio original: <?php echo e($chollo->precio); ?>€</p></div>
    <div class="col m-3 p-1"><p>Precio actual: <?php echo e($chollo->precio_descuento); ?>€</p></div>
    <div class="col m-3 p-1"><p>Puntuación: <?php echo e($chollo->puntuacion); ?></p></div>
    <div class="col m-3 p-1"><p>URL: <a href=<?php echo e($chollo->url); ?>><?php echo e($chollo->url); ?></a></p></div>
    <img src='<?php echo e(asset("img/$chollo->id-chollo-severo.png")); ?>' alt="Imagen del chollo <?php echo e($chollo->titulo); ?>">
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('static', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/nuevos.blade.php ENDPATH**/ ?>