<?php $__env->startSection('detalle'); ?>
    <h2>Detalle del chollo <?php echo e($chollo->titulo); ?></h2>
        <div>
            <p>Id: <?php echo e($chollo->id); ?></p> 
            <p>Categoría: <?php echo e($chollo->categoria); ?></p> 
            <p>Descripción: <?php echo e($chollo->descripcion); ?></p>
            <p>Precio original: <?php echo e($chollo->precio); ?>€</p>
            <p>Precio actual: <?php echo e($chollo->precio_descuento); ?>€</p>
            <p>Puntuación: <?php echo e($chollo->puntuacion); ?></p>
            <p>URL: <a href=<?php echo e($chollo->url); ?>><?php echo e($chollo->url); ?></a></p>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('static', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/chollos/detalle.blade.php ENDPATH**/ ?>