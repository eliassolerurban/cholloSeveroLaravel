<?php $__env->startSection('editar'); ?>
  <?php if(session('mensaje')): ?>
  <div class="btn btn-success">
      <?php echo e(session('mensaje')); ?>

  </div>
  <?php endif; ?>
  <div class="container">
    <form action="<?php echo e(route('editar', $chollo->id)); ?>" method="POST">
    <?php echo method_field('put'); ?>
    <?php echo csrf_field(); ?>
    <label for="titulo">Título: </label><input type="text" name="titulo" class="form-control mb-2" required autofocus value="<?php echo e($chollo->titulo); ?>">
    <label for="descripcion">Descripción: </label><input type="text" name="descripcion" class="form-control mb-2" required value="<?php echo e($chollo->descripcion); ?>">
    <label for="categoria">Categoría: </label><input type="text" name="categoria" class="form-control mb-2" required value="<?php echo e($chollo->categoria); ?>">
    <label for="url">URL:<input type="url" name="url" class="form-control mb-2" required value="<?php echo e($chollo->url); ?>">
    <label for="precio">Precio:<input type="number" name="precio" class="form-control mb-2" required value="<?php echo e($chollo->precio); ?>">
    <label for="precio_descuento">Precio actual:<input type="number" name="precio_descuento" class="form-control mb-2" required value="<?php echo e($chollo->precio_descuento); ?>">
    <label for="puntuacion">Puntuación:<input type="number" name="puntuacion" class="form-control mb-2" required value="<?php echo e($chollo->puntuacion); ?>">
    
    <button class="btn btn-primary btn-block" type="submit">
    Actualizar chollo
    </button>
    </form>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('static', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/chollos/editar.blade.php ENDPATH**/ ?>